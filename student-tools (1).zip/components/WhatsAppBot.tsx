"use client"

import { useState, useRef, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Message {
  text: string
  isUser: boolean
}

export default function WhatsAppBot() {
  const [messages, setMessages] = useState<Message[]>([
    { text: "Hello! I'm your Student Tools WhatsApp Bot. How can I help you today?", isUser: false }
  ])
  const [input, setInput] = useState('')
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, isUser: true }])
      setInput('')
      handleBotResponse(input)
    }
  }

  const handleBotResponse = (userInput: string) => {
    const lowerInput = userInput.toLowerCase()
    let botResponse = "I'm sorry, I didn't understand that. Can you try rephrasing or ask for help?"

    if (lowerInput.includes('hello') || lowerInput.includes('hi')) {
      botResponse = "Hello! How can I assist you with your studies today?"
    } else if (lowerInput.includes('help')) {
      botResponse = "I can help with various tasks. Try asking about:\n- CGPA calculation\n- Word counting\n- Quick quiz\n- Study timer"
    } else if (lowerInput.includes('cgpa')) {
      botResponse = "To calculate CGPA, please provide your grades and credit hours in this format:\nGrade1 Credits1, Grade2 Credits2, ...\nFor example: A 3, B 4, A 3"
    } else if (lowerInput.includes('word count')) {
      botResponse = "Please send the text you want me to count the words for."
    } else if (lowerInput.includes('quiz')) {
      botResponse = "Great! Let's have a quick quiz. What's the capital of France?"
    } else if (lowerInput.includes('timer')) {
      botResponse = "I can set a study timer for you. How many minutes would you like to study for?"
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { text: botResponse, isUser: false }])
    }, 1000)
  }

  return (
    <div className="flex flex-col h-[600px] max-w-md mx-auto border-4 border-black bg-green-200 shadow-brutal">
      <div className="bg-green-500 p-4 border-b-4 border-black">
        <h2 className="text-2xl font-bold text-white">Student Tools WhatsApp Bot</h2>
      </div>
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        {messages.map((message, index) => (
          <div
            key={index}
            className={`mb-4 ${
              message.isUser ? 'text-right' : 'text-left'
            }`}
          >
            <div
              className={`inline-block p-2 rounded-lg ${
                message.isUser
                  ? 'bg-blue-500 text-white'
                  : 'bg-white border-2 border-black'
              }`}
            >
              {message.text}
            </div>
          </div>
        ))}
      </ScrollArea>
      <div className="p-4 border-t-4 border-black bg-gray-100">
        <div className="flex space-x-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="flex-grow border-2 border-black"
          />
          <Button
            onClick={handleSend}
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 border-b-4 border-green-700 hover:border-green-800 active:border-t-4 active:border-b-0 transition-all duration-100"
          >
            Send
          </Button>
        </div>
      </div>
    </div>
  )
}

