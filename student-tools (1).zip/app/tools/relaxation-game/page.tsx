import RelaxationGame from "@/components/RelaxationGame"

export default function RelaxationGamePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Relaxation Game</h1>
      <RelaxationGame />
    </div>
  )
}

